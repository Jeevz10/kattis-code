#include <stdio.h>
using namespace std;

int main() {

	int num,test = 0;

	scanf("%d",&num);

	while (num != test) {
		test++;
		printf("%d Abracadabra\n",test);
	}

	return 0;
}

