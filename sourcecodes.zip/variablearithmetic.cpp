#include <bits/stdc++.h>
using namespace std;

int main() {
	map<string,int> log;
	string input;
	
	while (getline(cin,input)) {
		if (input == "0") {
			break;
		}
		
		istringstream iss (input);
		string in;
		deque<string> content;
		int count = 0;
		
		while (getline(iss,in,' ')) {
			
			content.push_back(in);	
			
			if (count == 1 && in == "+") {
				conte
			}
		}
	}
}

