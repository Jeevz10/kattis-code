#include <bits/stdc++.h>
using namespace std;

int main() {
	int a,j;
	
	cin >> a >> j;
	
	cout << (a*(j-1)) + 1 << endl;
	return 0;
}
