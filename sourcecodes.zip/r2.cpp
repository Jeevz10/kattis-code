#include <bits/stdc++.h>
using namespace std;

int main() {
	int r1,r2,s;
	
	cin >> r1 >> s;
	
	cout << (2 * s) - r1 << endl;
}
