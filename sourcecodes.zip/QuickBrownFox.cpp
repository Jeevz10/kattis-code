#include <bits/stdc++.h>
using namespace std;

int main() {
	
}


/* using cin >> input where input is a string will only capture "tell" when the input is "tell her hi"
	so, we use getline(cin,input)'
 	to convert every letter into lower case, you have to iterate through it and make arr[j] = tolower(arr[j])
 	isspace checks if character is a whitespace
 	isalpha checks if character
