#include <bits/stdc++.h>
using namespace std;

int main() {
	int h,v,l;
	
	cin >> h >> v;
	
	l = h / sin(v);
	
	cout << l << endl;
}

