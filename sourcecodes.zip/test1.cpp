#include <bits/stdc++.h>
using namespace std;

int main() {
	
	int a = 3;
	
	a* += 1;
	
	cout << a; 
}

