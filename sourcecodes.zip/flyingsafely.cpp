#include <bits/stdc++.h>
using namespace std;

int main() {
	int tc;
	
	cin >> tc;
	
	for (int i = 0;i < tc;i++) {
		int n,m;
		
		cin >> n >> m;
		
		for (int j = 0;j < m;j++) {
			int a,b;
			
			cin >> a >> b;
		
		}
		
		cout << n-1 << endl;
	}
	
	return 0;
}
